# -*- coding: utf-8 -*-
"""
hardening.py
============
移植元 pyside6-webusb (v0.0.4a0) の hardening.py と、ロジックとしては同一のファイル。
このファイルは元々 `time` と `threading` だけに依存する Qt 非依存の純粋ロジックだった
(判定関数・記述子ビルダーはどれも pyusb のデータ構造だけを見ている)ため、Firefox 版
(fox-webusb ネイティブホスト)への移植でもほぼ変更していない。変えたのは、呼び出し側が
「Qt の QTimer」から「常駐スレッド(__main__.py の hotplug スレッド)」に変わったことに
伴うコメントの言い回しだけで、判定ロジック・定数・アルゴリズムは一切変更していない。

bridge.py (このパッケージの) から import して、各メソッド内から判定関数・記述子ビルダーを
呼び出し、UsbHotplugWatcher を __main__.py 側の常駐スレッドから起動する、という使い方を
想定する。

--------------------------------------------------------------------------
なぜこれが必要か(2026年7月時点で確認した一次情報の要約。移植元での調査をそのまま踏襲)
--------------------------------------------------------------------------
* WebUSBはWICG(W3C Web Incubator Community Group)のDraftであり、正式なW3C
  勧告ではない。実装しているのはChromium系ブラウザ(Chrome/Edge/Opera/Samsung
  Internet等)のみ。
* Firefoxは公式スタンダードポジションでWebUSBを「harmful」(fingerprinting・
  セキュリティ上のリスクが大きい)と明記しており、実装する予定がない
  (mozilla/standards-positions#100、position: negative。2026年8月時点でも
  変更なしを確認済み)。このパッケージ(fox-webusb)自体が、まさにこの理由で
  「navigator.usb を Firefox 単体では絶対に持てない」ことの直接の帰結として、
  ブラウザ本体を書き換えずに済む唯一の経路であるネイティブメッセージング越しの
  外部ホストという構成を取っている(README.md 参照)。
  Safari/WebKitも同様に反対の立場を表明しており、iOS/iPadOS/macOS Safariの
  いずれにも実装されていない。
  → WebUSBはWeb系APIの中でも最も慎重な扱いが必要なものの一つ、というのが
    ブラウザベンダー間でのおおむね共通した認識である。
* Chromium自身は上記のリスクを軽減するため、単なる「サイトへの許可」以外に
  少なくとも次の多層防御を実装している:
    (1) 「保護対象インターフェースクラス」: Audio / HID / Mass Storage / Hub /
        Smart Card / Video / Audio-Video / Wireless Controller の8クラスは
        claimInterface自体をブラウザ側で拒否する(これらは別の専用API
        [WebHID・WebMIDI等]や高レベルOS機能が既にあり、WebUSBで生アクセス
        させる必要が無いため)。
    (2) 既知の脆弱/セキュリティ上重要なデバイスを列挙した明示的な
        ブロックリスト(vendor_id, product_id単位)。主にFIDO/U2Fの
        セキュリティキー各種。
    (3) セキュアコンテキスト(https/localhost/file://のみ)。
    (4) requestDevice()はユーザー操作(トラステッドイベント)からのみ呼び出し可能。
  本モジュールはこの(1)(2)をpyusb経由で再現し、(3)(4)はJS側
  (page_polyfill.js)側での追加チェックと合わせて実現する。

出典:
  - WebUSB仕様: https://wicg.github.io/webusb/
  - 保護対象インターフェースクラス8種の一覧: WebUSB仕様本文
    (index.bs の「Protected interface classes」表, #protected-interface-classes)
    を移植元プロジェクトが2026年7月に一次ソース(github.com/WICG/webusb)から
    直接取得して突き合わせたもの。
  - デバイスブロックリスト: chrome/browser/usb/usb_blocklist.cc
    (https://github.com/chromium/chromium/blob/main/chrome/browser/usb/usb_blocklist.cc
     移植元が2026年7月時点のmainブランチより、vendor_id/product_idの組のみを移植した
     ものをそのまま引き継いでいる。
     ★ 本家は随時更新されるため、定期的に上記URLを確認して追従すること。
     本モジュールの一覧はあくまで多層防御の一枚であり、下のHID等の
     インターフェースクラス丸ごと遮断の方が防御としては本質的に重要)
  - 参考実装 thegecko/webusb (Node.js): 2024年に非推奨化され、後継は
    npm "usb" パッケージ内蔵のWebUSB実装 (node-usb)。API形状
    (configurations/selectAlternateInterface/clearHalt/reset/serialNumber等)
    の突き合わせに使用した。isochronousTransferはnode-usb側でも
    「現状未対応」とされており、本実装でも同様に非対応として明示する
    (中途半端な実装で「動いているように見えて実は壊れている」状態を
    避けるため)。
"""

import time
import threading


# ============================================================
# 1) 保護対象インターフェースクラス
# ============================================================
# WebUSB仕様上、これらのクラスは claimInterface() 自体が拒否されるべきもの。
# ここで構造的に閉じることで、許可さえ得ていれば(=ユーザーがチューザーダイアログで
# 一度でも選んでしまえば)セキュリティキーやキーボード等のHIDインターフェースにも
# 生アクセスできてしまう、という事態を防ぐ。
PROTECTED_INTERFACE_CLASSES = {
    0x01: "Audio",
    0x03: "HID (Human Interface Device: セキュリティキー/キーボード/マウス等の大半)",
    0x08: "Mass Storage",
    0x09: "Hub",
    0x0B: "Smart Card (CCID)",
    0x0E: "Video",
    0x10: "Audio/Video",
    0xE0: "Wireless Controller (Bluetooth/Wireless USBアダプタ等)",
}


def is_protected_interface_class(b_interface_class) -> bool:
    """このインターフェースクラスは claimInterface を拒否すべきか"""
    try:
        return int(b_interface_class) in PROTECTED_INTERFACE_CLASSES
    except (TypeError, ValueError):
        return True  # 判定できない場合は安全側(拒否)に倒す


def protected_class_name(b_interface_class) -> str:
    try:
        return PROTECTED_INTERFACE_CLASSES.get(int(b_interface_class), "Unknown")
    except (TypeError, ValueError):
        return "Unknown"


# ============================================================
# 2) 既知セキュリティキー/認証デバイスのブロックリスト(多層防御の2枚目)
# ============================================================
# Chromiumの usb_blocklist.cc (2026-07時点のmain) から vendor_id/product_id の
# 組のみを移植したもの。実際の脅威はほぼ全てHIDインターフェースとして
# 提示されるため上のPROTECTED_INTERFACE_CLASSESで既にブロックされるはずだが、
# 「非HIDインターフェースでCTAP相当を喋る」将来の変則的デバイスに備えて
# デバイス単位でも明示的に遮断する。
KNOWN_SECURITY_KEY_BLOCKLIST = frozenset([
    (0x096e, 0x0850), (0x096e, 0x0852), (0x096e, 0x0853), (0x096e, 0x0854),
    (0x096e, 0x0856), (0x096e, 0x0858), (0x096e, 0x085a), (0x096e, 0x085b),
    (0x096e, 0x0880),
    (0x09c3, 0x0023),
    (0x1050, 0x0010), (0x1050, 0x0018), (0x1050, 0x0030),
    (0x1050, 0x0110), (0x1050, 0x0111), (0x1050, 0x0112), (0x1050, 0x0113),
    (0x1050, 0x0114), (0x1050, 0x0115), (0x1050, 0x0116), (0x1050, 0x0120),
    (0x1050, 0x0200), (0x1050, 0x0211),
    (0x1050, 0x0401), (0x1050, 0x0402), (0x1050, 0x0403), (0x1050, 0x0404),
    (0x1050, 0x0405), (0x1050, 0x0406), (0x1050, 0x0407), (0x1050, 0x0410),
    (0x10c4, 0x8acf),
    (0x18d1, 0x5026),
    (0x1a44, 0x00bb),
    (0x1d50, 0x60fc),
    (0x1e0d, 0xf1ae), (0x1e0d, 0xf1d0),
    (0x1ea8, 0xf025),
    (0x20a0, 0x4287),
    (0x24dc, 0x0101),
    (0x2581, 0xf1d0),
    (0x2abe, 0x1002),
    (0x2ccf, 0x0880),
])


def is_blocklisted_device(vendor_id, product_id) -> bool:
    try:
        return (int(vendor_id), int(product_id)) in KNOWN_SECURITY_KEY_BLOCKLIST
    except (TypeError, ValueError):
        return True


def device_is_fully_blocked(dev) -> bool:
    """デバイス単位でブロックリストに一致するか(こちらはgetDevices/openDeviceの
    時点、つまりインターフェースをまだ見ていない段階での粗いチェック)。
    個々のインターフェースクラスのチェックは claimInterface 側で別途行う。"""
    try:
        return is_blocklisted_device(dev.idVendor, dev.idProduct)
    except Exception:
        return True


# ============================================================
# 3) BCDバージョン変換 (bcdUSB / bcdDevice -> major.minor.subminor)
# ============================================================
def bcd_to_version(bcd_value) -> tuple:
    """USB記述子のBCD値(例:0x0210)を(major, minor, subminor)=(2,1,0)に変換する。
    WebUSB仕様のUSBDevice.usbVersionMajor等はこの分解方式を使う。"""
    try:
        v = int(bcd_value)
    except (TypeError, ValueError):
        return (0, 0, 0)
    major = (v >> 8) & 0xFF
    minor = (v >> 4) & 0x0F
    subminor = v & 0x0F
    return (major, minor, subminor)


# ============================================================
# 4) リッチなデバイス記述子ビルダー
# ============================================================
# WebUSB仕様が持つ configurations (interfaces/alternates/endpointsのツリー)や
# serialNumber, usbVersion*, deviceVersion* 等を、実機の記述子から可能な限り
# 汎用ブラウザ相当の形へ組み立てる。これが無いと「エンドポイント番号やインター
# フェース番号を呼び出し元サイトが事前に知っている」ことが前提になってしまい、
# 汎用のWebUSB対応ハードウェアSDKがそのままでは動かない。
def build_device_descriptor(dev, usb_util, include_configurations=True) -> dict:
    manufacturer = product = serial = None
    try:
        if getattr(dev, "iManufacturer", 0):
            manufacturer = usb_util.get_string(dev, dev.iManufacturer)
    except Exception:
        pass
    try:
        if getattr(dev, "iProduct", 0):
            product = usb_util.get_string(dev, dev.iProduct)
    except Exception:
        pass
    try:
        if getattr(dev, "iSerialNumber", 0):
            serial = usb_util.get_string(dev, dev.iSerialNumber)
    except Exception:
        pass

    usb_major, usb_minor, usb_sub = bcd_to_version(getattr(dev, "bcdUSB", 0))
    dev_major, dev_minor, dev_sub = bcd_to_version(getattr(dev, "bcdDevice", 0))

    # 実機が「今実際にどのコンフィグレーションで動作しているか」(GET_CONFIGURATION相当)。
    # 取得できない場合はNoneのままにし、JS側で先頭要素へ安全側フォールバックする。
    active_cfg_value = None
    try:
        active_cfg_value = dev.get_active_configuration().bConfigurationValue
    except Exception:
        active_cfg_value = None

    info = {
        "vendorId": dev.idVendor,
        "productId": dev.idProduct,
        "manufacturerName": manufacturer,
        "productName": product,
        "serialNumber": serial,
        "deviceClass": getattr(dev, "bDeviceClass", 0),
        "deviceSubclass": getattr(dev, "bDeviceSubClass", 0),
        "deviceProtocol": getattr(dev, "bDeviceProtocol", 0),
        "usbVersionMajor": usb_major, "usbVersionMinor": usb_minor, "usbVersionSubminor": usb_sub,
        "deviceVersionMajor": dev_major, "deviceVersionMinor": dev_minor, "deviceVersionSubminor": dev_sub,
        "configurations": [],
        "activeConfigurationValue": active_cfg_value,
    }

    if include_configurations:
        info["configurations"] = build_configurations_tree(dev, usb_util)
    return info


def build_configurations_tree(dev, usb_util) -> list:
    """dev配下の全Configuration/Interface(=各AlternateSetting)/Endpointを
    WebUSB仕様相当のツリー構造に変換する。1個の記述子取得に失敗しても
    全体を巻き込んで失敗させない(壊れた/変則的な記述子を持つ安物USB機器が
    実世界には少なくないため)。"""
    configurations = []
    try:
        cfg_iter = list(dev)
    except Exception:
        return configurations

    for cfg in cfg_iter:
        try:
            interfaces_by_number = {}
            for intf in cfg:
                try:
                    inum = intf.bInterfaceNumber
                    # spec: USBAlternateInterface.interfaceName は
                    # 「interface descriptorのiInterfaceが指すstring descriptorの値」
                    # (pyusbのInterfaceオブジェクトはiInterface属性を公開していることを
                    # ソース確認済み)。取得できない/未定義な機器も多いため、他の文字列
                    # 記述子(manufacturer/product/serial)と同じくベストエフォートで
                    # Noneにフォールバックする。
                    interface_name = None
                    try:
                        if getattr(intf, "iInterface", 0):
                            interface_name = usb_util.get_string(dev, intf.iInterface)
                    except Exception:
                        pass
                    alt = {
                        "alternateSetting": intf.bAlternateSetting,
                        "interfaceClass": intf.bInterfaceClass,
                        "interfaceSubclass": intf.bInterfaceSubClass,
                        "interfaceProtocol": intf.bInterfaceProtocol,
                        "interfaceProtected": is_protected_interface_class(intf.bInterfaceClass),
                        "interfaceName": interface_name,
                        "endpoints": [],
                    }
                    for ep in intf:
                        try:
                            ep_type = usb_util.endpoint_type(ep.bmAttributes)
                            # spec(USBAlternateInterface constructor): bmAttributesが
                            # Control Transfer Type(下位2bitが00)を示す記述子は
                            # endpoints一覧から除外する("There shouldn't be any endpoint
                            # object belongs to Control Transfer Type" との注記どおり)。
                            if ep_type == usb_util.ENDPOINT_TYPE_CTRL:
                                continue
                            direction = usb_util.endpoint_direction(ep.bEndpointAddress)
                            alt["endpoints"].append({
                                "endpointNumber": ep.bEndpointAddress & 0x0F,
                                "direction": "in" if direction == usb_util.ENDPOINT_IN else "out",
                                "type": {
                                    usb_util.ENDPOINT_TYPE_BULK: "bulk",
                                    usb_util.ENDPOINT_TYPE_INTR: "interrupt",
                                    usb_util.ENDPOINT_TYPE_ISO: "isochronous",
                                }.get(ep_type, "unknown"),
                                "packetSize": getattr(ep, "wMaxPacketSize", 0),
                            })
                        except Exception as e:
                            # 🔍 品質改善(v0.0.0a0、移植元v0.0.4b1のruff指摘を踏襲):
                            # 以前はここを完全に無言でcontinueしていた。記述子が
                            # 多少崩れたデバイスでendpointが1つ2つ丸ごと消える場合、
                            # 原因が一切追えなかった(=「デバイスが繋がっているのに
                            # 一部のendpointが見えない」という調査困難な状況の温床)。
                            # 他の箇所(bridge.py)と同じ"例外を無視"表記に揃え、
                            # 制御フロー(continueして列挙を続ける)自体は変更しない。
                            print(f"[fox-webusb-host] build_configurations_tree(endpoint): 例外を無視: {e}")
                            continue
                    interfaces_by_number.setdefault(inum, []).append(alt)
                except Exception as e:
                    print(f"[fox-webusb-host] build_configurations_tree(alternate): 例外を無視: {e}")
                    continue

            interfaces_list = [
                {"interfaceNumber": inum, "alternates": alts}
                for inum, alts in sorted(interfaces_by_number.items())
            ]
            # spec: USBConfiguration.configurationName は
            # 「configuration descriptorのiConfigurationが指すstring descriptorの値」
            configuration_name = None
            try:
                if getattr(cfg, "iConfiguration", 0):
                    configuration_name = usb_util.get_string(dev, cfg.iConfiguration)
            except Exception:
                pass
            configurations.append({
                "configurationValue": getattr(cfg, "bConfigurationValue", 0),
                "configurationName": configuration_name,
                "interfaces": interfaces_list,
            })
        except Exception as e:
            print(f"[fox-webusb-host] build_configurations_tree(configuration): 例外を無視: {e}")
            continue
    return configurations


def interface_class_for(dev, interface_number, alternate_setting=0):
    """指定インターフェース番号のbInterfaceClassを、デバイスの現在アクティブな
    configuration内から取得する(claimInterface/controlTransfer検証時のHID等
    ブロック判定に使う)。取得できない場合は-1ではなくNoneを返す
    (int(None)がTypeErrorを送出し、is_protected_interface_class()の
    「判定不能なら安全側[拒否]に倒す」フォールバックへ正しく落ちるようにするため)。
    探索は常に「現在アクティブなconfiguration」内のものだけに限定する
    (非アクティブ側にたまたま同じ番号のインターフェースがあった場合に誤って
    拾わないため)。アクティブなconfiguration自体が特定できない場合も
    安全側(None)に倒す。
    🛡️ v0.0.0a1(独立したセキュリティ監査を受けて): alternate_setting引数を
    追加した。以前はこの関数がalternate settingという概念を一切知らず、
    「指定interface番号に一致する最初のInterfaceエントリ」のクラスだけを
    返していた。複合デバイスがalternate setting 0を無害なクラス、alternate
    setting 1を保護対象クラス(HID等)として宣言した場合、claim_interface()の
    保護対象クラス判定や_control_transfer_validation_error()のinterface
    recipient分岐がこれだけを根拠に許可してしまい得た
    (pyside6-webusb側の監査で見つかったCVE-2018-6125と同種の回避策。
    詳細はCHANGELOG.md参照)。このモジュール内の他のあらゆる箇所
    (_find_claimed_endpoint()、claim_interface()直後のset_interface_altsetting
    呼び出し)は既に「claim済みインターフェースは常にUSB仕様どおり
    alternate setting 0から始まり、selectAlternateInterface()でのみ変わる」
    という前提でinfo["active_alternates"]を追跡・参照していたため、
    デフォルト値を0にしておけば、既存の全呼び出し元(2引数のまま)は
    従来どおり「claim直後、またはalternate切り替え前」の状態については
    正しく動き続け、選択中のalternate settingを追跡している呼び出し元
    (claim_interface、_control_transfer_validation_error)は
    info["active_alternates"].get(interface_number, 0)を明示的に渡すことで、
    実際に選択されているalternate settingだけを見るようになる。"""
    try:
        cfg = dev.get_active_configuration()
    except Exception:
        return None
    try:
        for intf in cfg:
            if intf.bInterfaceNumber == interface_number and getattr(intf, "bAlternateSetting", 0) == alternate_setting:
                return intf.bInterfaceClass
    except Exception:
        pass
    return None


# ============================================================
# 5) 接続監視(connect/disconnectイベント)
# ============================================================
class UsbHotplugWatcher:
    """
    navigator.usb の 'connect'/'disconnect' イベント相当を実現するための
    ポーリング監視。pyusbはOS横断のホットプラグコールバックAPIを持たない
    (libusb自体にはあるがOS依存で不安定なため)、実用上は短間隔ポーリングで
    十分かつ確実。

    このクラス自体は駆動方法(Qtのイベントループか、素の常駐スレッドか)に
    依存しない「純粋な差分検出ロジック」だけを提供する。呼び出し側は一定間隔で
    poll() を呼び、戻り値の (connected, disconnected) のうち許可済みオリジンに
    関係するものだけを 'connect'/'disconnect' イベントとして配送する。

    fox-webusb (Firefox版) では __main__.py の常駐スレッドが1.5秒間隔で
    poll() を呼ぶ。移植元(pyside6-webusb)では QTimer がこれを担っていたが、
    poll() 自体のロジックはどちらの駆動方式でも全く同じものが使える。
    """

    def __init__(self, pyusb_finder):
        # pyusb_finder: 引数無しで呼ぶと現在のUSBデバイス一覧
        # (vendor_id, product_id)のsetを返す callable
        self._pyusb_finder = pyusb_finder
        self._known = set()
        self._lock = threading.Lock()
        self._last_poll = 0.0

    def poll(self):
        with self._lock:
            try:
                current = self._pyusb_finder()
            except Exception:
                return [], []
            connected = sorted(current - self._known)
            disconnected = sorted(self._known - current)
            self._known = current
            self._last_poll = time.time()
            return connected, disconnected


# ============================================================
# 6) requestDevice()/getDevices() のフィルタ照合 (WebUSB仕様 §5 Device Enumeration)
# ============================================================
# 出典: https://wicg.github.io/webusb/#dom-usb-requestdevice 内で定義されている
#   「A USB device device matches a device filter filter」
#   「A USB interface interface matches an interface filter filter」
#   「A USBDeviceFilter filter is valid」
# の3アルゴリズムをそのまま移植したもの。
#
# is_valid_usb_device_filter()の妥当性チェック自体はJS側
# (page_polyfill.js)でTypeErrorとして先に弾く設計とし、ここへ渡って
# くるfiltersは構造的に妥当なものだけという前提を置いている(Python側は
# 念のため存在チェック程度は行うが、ここでの主目的は「一致判定」)。
def is_valid_usb_device_filter(filt) -> bool:
    """'A USBDeviceFilter filter is valid'(仕様7章相当)。より上位の
    フィールドを伴わない下位フィールドの指定はinvalid
    (例: vendorId無しでproductIdだけを指定 等)。"""
    if not isinstance(filt, dict):
        return False
    if "productId" in filt and "vendorId" not in filt:
        return False
    if "subclassCode" in filt and "classCode" not in filt:
        return False
    if "protocolCode" in filt and "subclassCode" not in filt:
        return False
    return True


def _device_interface_class_tuples(dev) -> list:
    """このデバイスが持つ全インターフェース(・全alternate)の
    (bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol)を集めたもの。
    フィルタのclassCode照合で「インターフェース単位のクラス」も見るために使う
    (仕様: デバイス全体のbDeviceClassだけでなく、いずれかのインターフェースが
    一致すればそれだけでデバイス全体もmatch扱いになる。複合デバイス
    [composite device] がbDeviceClass=0xFF[vendor-specific]を名乗りつつ
    個々のインターフェースで実際のクラスを申告するケースに対応するため)。
    記述子が壊れている/読めない機器を1台巻き込んで全体を失敗させないよう、
    個々の失敗は握りつぶして安全側(=そのインターフェースは無視)に倒す。"""
    tuples = []
    try:
        for cfg in dev:
            try:
                for intf in cfg:
                    try:
                        tuples.append((intf.bInterfaceClass, intf.bInterfaceSubClass, intf.bInterfaceProtocol))
                    except Exception as e:
                        # 🔍 品質改善(v0.0.0a0、移植元v0.0.4b1のruff指摘を踏襲):
                        # build_configurations_treeと同じ理由で可視化する。この関数は
                        # フィルタ照合のたびに呼ばれうるため、壊れた記述子を持つ
                        # デバイスが挿さったままだと繰り返し出力されうる点に注意
                        # (それでも「一度も分からない」よりは良い)。
                        print(f"[fox-webusb-host] _device_interface_class_tuples(interface): 例外を無視: {e}")
                        continue
            except Exception:
                continue
    except Exception:
        pass
    return tuples


def _interface_matches_filter(iface_triplet, filt) -> bool:
    """'A USB interface interface matches an interface filter filter'"""
    cls, sub, proto = iface_triplet
    if "classCode" in filt and cls != filt["classCode"]:
        return False
    if "subclassCode" in filt and sub != filt["subclassCode"]:
        return False
    if "protocolCode" in filt and proto != filt["protocolCode"]:
        return False
    return True


def device_matches_usb_filter(dev, usb_util, filt) -> bool:
    """'A USB device device matches a device filter filter'(仕様の手順をそのまま)。
    filtに存在しないキーは無条件一致(=絞り込みなし)として扱う。"""
    try:
        if not isinstance(filt, dict):
            return False
        if "vendorId" in filt and getattr(dev, "idVendor", None) != filt["vendorId"]:
            return False
        if "productId" in filt and getattr(dev, "idProduct", None) != filt["productId"]:
            return False
        if "serialNumber" in filt:
            serial = None
            try:
                if getattr(dev, "iSerialNumber", 0):
                    serial = usb_util.get_string(dev, dev.iSerialNumber)
            except Exception:
                serial = None  # 仕様: 読み取りエラー時はmismatch扱い
            if serial != filt["serialNumber"]:
                return False
        if "classCode" in filt:
            iface_tuples = _device_interface_class_tuples(dev)
            if any(_interface_matches_filter(t, filt) for t in iface_tuples):
                return True  # 仕様どおり: いずれか1つのインターフェースが一致すれば即match
            if getattr(dev, "bDeviceClass", None) != filt["classCode"]:
                return False
            if "subclassCode" in filt and getattr(dev, "bDeviceSubClass", None) != filt["subclassCode"]:
                return False
            if "protocolCode" in filt and getattr(dev, "bDeviceProtocol", None) != filt["protocolCode"]:
                return False
        return True
    except Exception:
        return False


def device_matches_any_usb_filter(dev, usb_util, filters) -> bool:
    """filtersが空リストの場合は仕様どおり「一致するものなし」
    (=1台も候補に残らない)。サイトが「フィルタなしで全デバイスを見せたい」
    場合、仕様上は filters: [{}] (空オブジェクト。どのフィールドも
    指定しないので無条件一致)を渡す必要がある——これは実際のChromiumの
    挙動も同じで、本実装だけの制約ではない。"""
    if not filters:
        return False
    try:
        return any(device_matches_usb_filter(dev, usb_util, f) for f in filters)
    except Exception:
        return False


# ============================================================
# 7) 転送失敗のうち「STALL」を仕様どおりUSBTransferStatus('stall')として扱う
# ============================================================
# 出典: https://wicg.github.io/webusb/#usbtransferstatus および6.1.2節の
# transferIn()等の仕様、および仕様6節の使用例(データチャンネルがエラーを
# STALLで通知し、呼び出し側がresult.status==='stall'を見てclearHalt()で
# 解除してから続行する、という一連の流れそのものが仕様の主要な用例)。
# 実際のブラウザはSTALLをPromiseのrejectではなく、status:'stall'を伴う
# "成功"resolveとして返す。
#
# pyusb(libusb1バックエンド)はSTALL(libusbのLIBUSB_ERROR_PIPE)を検出すると
# usb.core.USBError を送出し、errno=32("Pipe error")として報告することを、
# 複数件のpyusb issue/discussion(pyusb/pyusb#207, #351, #414, #415等、
# Linux/Windows双方の報告例)で確認した。この errno=32 は生のOS errnoでは
# なく、pyusbが usb/backend/libusb1.py 内で libusbのエラーコードから
# 固定的に変換した値であるため、OS非依存で信頼できる。
def is_stall_error(exc) -> bool:
    try:
        if getattr(exc, "errno", None) == 32:
            return True
    except Exception:
        pass
    try:
        msg = str(exc).lower()
        return "pipe error" in msg or "stall" in msg
    except Exception:
        return False


# ============================================================
# 7b) 転送失敗のうち「babble」を仕様どおりUSBTransferStatus('babble')として扱う
# ============================================================
# babbleはIN方向(=デバイスからホストへ、要求より多くのデータが返ってきた)
# 特有の状態であり、OUT方向のtransferOut()/controlTransferOut()/
# isochronousTransferOut()にはbabbleという概念自体が存在しない(spec上も
# 定義されていない)ため、is_babble_errorはIN方向の各メソッドでのみ使う。
#
# pyusb(libusb1バックエンド)は、デバイスが要求サイズを超えるデータを返した
# 場合、libusbのLIBUSB_ERROR_OVERFLOW(-8)を検出してusb.core.USBErrorを送出し、
# errno=75(Linux上のEOVERFLOW)、メッセージ"Overflow"として報告することを、
# is_stall_error と全く同じ手法で実機検証済み: str(exc) == '[Errno 75] Overflow'。
#
# 既知の限界: pyusbの同期read API(dev.read()等)は、overflow発生時に
# 例外を送出するのみで、その例外から「オーバーフロー発生までに実際に何
# バイト受信できていたか」を取得する手段を提供しない。そのため、この実装が
# babbleを報告する際のdataは(stallの場合と同様)常に空になる — 仕様が
# 求める「bytesTransferredぶんの部分データ」の再現はできていない。
def is_babble_error(exc) -> bool:
    try:
        if getattr(exc, "errno", None) == 75:
            return True
    except Exception:
        pass
    try:
        msg = str(exc).lower()
        return "overflow" in msg or "babble" in msg
    except Exception:
        return False


# ============================================================
# 8) 拡張機能へ返すエラーメッセージの無害化
# ============================================================
# pyusb/libusb由来の例外メッセージをそのままJSON化して返していたが、
# バックエンド・OSによっては改行やタブを含むメッセージを返すことがあり、
# 極端に長いメッセージが返る可能性もゼロではない。JSON自体はこれらの文字を
# 正しくエスケープするので壊れはしないが、拡張機能側でのログ表示崩れや、
# 万一の下流ログインジェクションを避けるための保険として正規化する。
def safe_error_str(exc, max_len: int = 500) -> str:
    """例外を、制御文字を含まない・長さの上限が保証された文字列に変換する。
    "SecurityError:"のような、こちら側で明示的に付けている振り分け用の
    接頭辞(文字列リテラルとして自前で組み立てているもので、str(exc)の
    生の出力ではない)には影響しない。"""
    try:
        msg = str(exc)
    except Exception:
        return "unknown error"
    msg = msg.replace("\n", " ").replace("\r", " ").replace("\t", " ")
    if len(msg) > max_len:
        msg = msg[:max_len] + "…"
    return msg


# 🛡️ v0.0.0a1: pyside6-webusb側の独立したセキュリティ監査(No.3)で見つかった
# 問題をこちらにも移植したもの。U+202A-U+202E(LRE/RLE/PDF/LRO/RLO、いわゆる
# "bidi override")とU+2066-U+2069(LRI/RLI/FSI/PDI)。RLO等を使うと
# "cod.exe" のような文字列の表示順を入れ替えて "exe.doc" のように見せかけ
# られる、実際に知られたUIスプーフィング手法。
_BIDI_OVERRIDE_CHARS = "".join(chr(c) for c in list(range(0x202A, 0x202F)) + list(range(0x2066, 0x206A)))
_DEVICE_STRING_MAX_LEN = 255  # USB文字列記述子自体の実務上の上限より十分大きい保守的な上限


def sanitize_device_string(value, max_len: int = _DEVICE_STRING_MAX_LEN):
    """USBデバイス自身が返す文字列記述子(manufacturerName/productName/
    serialNumber/configurationName/interfaceName)向けのサニタイザー。
    🛡️ これらの文字列はエラーメッセージ(safe_error_str()の対象)よりも
    さらに攻撃者(=デバイス自身)制御下にあるにもかかわらず、従来は
    safe_error_str()と同水準のサニタイズが一切適用されておらず、制御文字・
    bidiオーバーライド文字・無制限長がbuild_device_descriptor()を素通り
    していた。チューザーダイアログ(Tkinter)を含む全ての利用箇所で一律に
    安全になるよう、生成元であるこの関数側で対処する。
    ⚠️ Tkinterのchooser_dialog.py自体はQtのQLabelと違いデフォルトで
    リッチテキスト/HTMLを解釈しないため、pyside6-webusb版のNo.3で
    別途必要だった「QLabelにPlainTextを強制する」対応に相当するものは
    fox-webusb側には不要(Tkinter Labelは常にプレーンテキスト表示)。
    ただし制御文字・bidiオーバーライド文字は描画エンジン(フォント
    シェーピング)レベルの話でツールキットを問わず影響し得るため、
    こちらのサニタイズは同様に必要。
    None/非文字列はそのまま返す(iManufacturer等が無い場合のNoneは
    正当な「無し」を表す値であり、空文字列に化けさせるべきではない)。"""
    if not isinstance(value, str):
        return value
    cleaned = "".join(ch for ch in value if not (ch <= "\x1f" or "\x7f" <= ch <= "\x9f"))
    cleaned = "".join(ch for ch in cleaned if ch not in _BIDI_OVERRIDE_CHARS)
    if len(cleaned) > max_len:
        cleaned = cleaned[:max_len] + "…"
    return cleaned


# ============================================================
# 9) 大容量データ転送(WebADB等)向けの実務上のガード
# ============================================================
# WebUSBは「ADB (Android Debug Bridge) をブラウザから直接叩く」用途
# (WebADB/Tangoなど)で広く使われている。ADBプロトコルはUSB bulk転送を
# 使い、1回のtransferOut()/transferIn()で数百KB〜数MBのペイロードを
# やり取りすることが珍しくない。以下は、そうした「正当な大容量転送は
# 通したいが、行儀の悪い/悪意あるページが天文学的なサイズを要求してホスト
# 側プロセスに無制限のメモリ確保・無期限ブロックを強制することは防ぎたい」
# という要求のための、この実装独自の防御的な仕組み(いずれも仕様が要求する
# 値ではない)。
#
# 🦊 fox-webusb固有の注記: これらの上限はpyusb/libusb側の安全弁であり、
# Firefoxのネイティブメッセージングが課す「ホスト→拡張機能方向は1メッセージ
# 最大1MB」という別の制約(https://developer.mozilla.org/.../Native_messaging
# で確認済み)とは独立している。後者は protocol.py 側の透過的なチャンク分割
# (base64化した本文を約700KB単位に分けて複数ネイティブメッセージへ分割し、
# 拡張機能側で結合してから1個の論理レスポンスとして扱う)で吸収しており、
# ここで定義する64MiB等の上限はそのチャンク分割の「内側」で従来どおり効く
# (=JSから見える transferIn(length) の意味・挙動は移植元と変わらない)。

# controlTransferIn()のlengthは仕様上 WebIDL の unsigned short (0-65535)。
CONTROL_TRANSFER_MAX_LENGTH = 0xFFFF

# transferIn()(=bulkTransferIn)のlengthは仕様上unsigned long(最大約42億)
# だが、実在するUSBデバイスがそれほど巨大な単発readを必要とすることは無い。
# WebADBのような正当な大容量転送用途(1コールあたり数百KB〜数MB程度)を
# 十分上回りつつ、暴走を防げる実務上の上限として64MiBを設ける。
BULK_TRANSFER_MAX_LENGTH = 64 * 1024 * 1024

# isochronousTransferIn()のpacketLengths合計についても同じ理由で上限を
# 設ける(個々のパケットは通常1〜数KB程度だが、パケット数が多い呼び出しを
# 積み上げられた場合の保険)。
ISOCHRONOUS_TRANSFER_MAX_TOTAL_LENGTH = 16 * 1024 * 1024

# バルク/コントロール転送のタイムアウト(ミリ秒)を、転送予定バイト数に応じて
# スケールさせる。
#
# 位置づけ: WebUSBのtransferIn()/transferOut()/controlTransferIn()/
# controlTransferOut()はいずれも「timeout」という概念自体をJSへ公開して
# いない(=呼び出し側は「時間がかかっても完了を待つ」ことを期待できる)。
# この実装は内部的にpyusb(=libusb)へタイムアウト付きで転送を依頼する
# 都合上、何らかの値を選ばなければならない立場にある。
#
# 固定5秒では、低速リンクや大容量ペイロード(WebADBのファイルpush等、
# 数百KB〜数MB規模になりうる)で、正当な転送が完了前に打ち切られてしまう。
# かといって無期限ブロック(timeout=None)にすると、ワーカースレッドが
# 応答不能なデバイス相手にブロックし続け、後続のリクエストが詰まってしまう
# (Qt版ではメインスレッドがフリーズする問題だったが、fox-webusbでは
# 「ワーカースレッドの単一キューが詰まる」問題として同種のリスクが残る)。
# 両者の折衷として、ベースタイムアウトに「保守的に見積もった最低速度」で
# 計算した所要時間を加算しつつ、上限もかけて無期限ブロックにはしない、
# という現実的なスケーリングを行う。
_TRANSFER_TIMEOUT_MIN_MS = 5000
_TRANSFER_TIMEOUT_MAX_MS = 120000
_TRANSFER_ASSUMED_MIN_THROUGHPUT_BYTES_PER_MS = 100  # 100 KB/s 相当の保守的な下限


def scaled_transfer_timeout_ms(payload_size_bytes: int) -> int:
    """payload_size_bytes バイトの転送に許すタイムアウト(ミリ秒)を返す。
    小さい転送では最低5秒、大きい転送では100KB/s相当の下限スループットを
    見積もって加算し、最大120秒で頭打ちにする。"""
    try:
        size = max(0, int(payload_size_bytes))
    except Exception:
        size = 0
    scaled = _TRANSFER_TIMEOUT_MIN_MS + (size // _TRANSFER_ASSUMED_MIN_THROUGHPUT_BYTES_PER_MS)
    return min(scaled, _TRANSFER_TIMEOUT_MAX_MS)
