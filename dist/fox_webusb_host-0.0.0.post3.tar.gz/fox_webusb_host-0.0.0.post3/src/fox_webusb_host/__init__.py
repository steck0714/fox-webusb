# -*- coding: utf-8 -*-
"""
fox-webusb ネイティブメッセージングホスト。

移植元 pyside6-webusb (v0.0.4b0) の「PySide6/QtWebEngineアプリにnavigator.usb
ポリフィルを注入するQtブリッジ」を、「Firefox拡張機能から起動される、
ブラウザ本体とは独立したネイティブメッセージングホスト」として書き直したもの。
詳しい設計についてはリポジトリ直下のREADME.md、および bridge.py 冒頭の
docstringを参照。

コードネーム: fox-webusb
バージョン: 0.0.0.post3 (v0.0.0.post2から機能面の変更なし。旧バージョン名は
0.0.0.2——当初はv0.0.0a1[現0.0.0.post2]に残っていたFirefoxアドオンlinter
[web-ext lint/AMOのvalidator]の警告[VERSION_FORMAT_DEPRECATED: Manifest
V3以降で使えなくなる英字入りバージョン文字列]を解消する目的で、"a1"のような
接尾辞ではなく4つ目の数字セグメントとして配布していた([0.0.0.1]でinnerHTML
への動的な値の代入等は既に解消済みだったため、当時残っていたのはバージョン
文字列のみだった)。今回、fox-webusb-host(PyPI配布物)のバージョン付けを
pyside6-webusb[移植元プロジェクト]のdist/命名規則[X.Y.Z / X.Y.Z.postN]に
揃えるため0.0.0.post3へ改称。VERSION_FORMAT_DEPRECATEDはFirefoxアドオン
本体のmanifest.jsonにのみ適用される制約でありPyPIパッケージ自体のバージョン
文字列には及ばないため、英字を含む"post"接尾辞を用いても支障はないと判断
している——manifest.json側のバージョンは本パッケージとは独立に、今後も
英字なしの数字のみで管理する。詳細はCHANGELOG.md [0.0.0.post3、旧0.0.0.2]
を参照)
"""

__version__ = "0.0.0.post3"
__codename__ = "fox-webusb"
