from .fox_webusb_accel import *

__doc__ = fox_webusb_accel.__doc__
if hasattr(fox_webusb_accel, "__all__"):
    __all__ = fox_webusb_accel.__all__